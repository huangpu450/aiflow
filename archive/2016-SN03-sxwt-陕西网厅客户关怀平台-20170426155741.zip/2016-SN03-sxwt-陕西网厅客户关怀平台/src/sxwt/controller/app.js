'use strict';

import Base from './base.js';

export default class extends Base {
    // add custom action like this
    /**
     * index action
     * @return {Promise} []
     */
    // indexAction() {
    //     return this.display();
    // }
}