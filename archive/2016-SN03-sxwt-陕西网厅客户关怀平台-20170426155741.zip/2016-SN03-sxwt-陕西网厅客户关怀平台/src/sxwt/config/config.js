'use strict';
/**
 * config
 */
export default {
};