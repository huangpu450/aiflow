'use strict';

export default {
  
};