'use strict';
/**
 * config
 */
export default {
    //key: value
    port: 1234,
    default_controller: "app",
    pro_conf_pref: 'aipro'
};
