'use strict';
import Common from '../../common/controller/common.js';

export default class extends Common {
    /**
     * some base method in here
     */
}