'use strict';
/**
 * the project data
 *
 * @author: yunzhi li
 * @version: 2016/11/2 9:34
 *           $Id$
 */

export default {
    'pages': {
        index: {
            action: 'index',
            title: '首页',
            data: {}
        }
    }
}